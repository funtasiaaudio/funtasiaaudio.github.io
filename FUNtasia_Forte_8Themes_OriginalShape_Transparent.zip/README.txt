FUNtasia Forte — 8 Studio Theme Colors

Color palette sourced from https://funtasiaaudio.github.io/studio/official/ja/ (theme swatches).
Logo source: Sage Logo(1).jpeg (1536 x 1536; supplied by owner in conversation).
All eight assets use EXACTLY the same alpha silhouette extracted from the supplied original bitmap. Only flat RGB color changes.
Original JPEG white background removed; edges retain soft alpha.
Output dimensions: 4608 x 4608 pixels, PNG RGBA transparent.
This is a threefold raster upscale from the 1536px source, not true vector artwork.
Colors:
Charcoal: #626A6A
Deep_Brown: #927366
Lapis_Lazuli: #3C619E
Lavender: #8E6BA8
Coral_Red: #AE717D
Mikan_Orange: #B77B46
Sakura_Pink: #AD788F
Aquamarine: #4B8B98

Please check ink contrast on light/dark fabric and sample print before commercial production.
