FUNtasia – Forte + wordmark, Studio 8 themes

Charcoal: #626A6A
Deep Brown: #927366
Lapis Lazuli: #3C619E
Lavender: #8E6BA8
Coral Red: #AE717D
Mikan Orange: #B77B46
Sakura Pink: #AD788F
Aquamarine: #4B8B98

4500 × 5400 px; RGBA transparent PNG. Exact original image alpha channel copied in every colour. Original graphic retained unchanged; these are raster images, not vector files.
