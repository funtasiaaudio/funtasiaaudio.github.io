# FUNtasia Goods — Official Logo Assets (Publishing Kit)

This kit is a site-publication draft, not an automatically published live page.

## Contents

- `downloads/FUNtasia_Forte_3Colors.zip`: Forte symbol, 3 colors, transparent PNG, 3072 × 3072.
- `downloads/FUNtasia_Forte_Wordmark_3Colors.zip`: Forte with FUNtasia text, 3 colors, transparent PNG, 4500 × 5400.
- `downloads/Hueliang_DJ_Black_White.zip`: Hʉeliang DJ wordmark, black and white, transparent PNG, 4800 × 1440.
- `downloads/FUNtasia_All_Logo_Assets.zip`: All 8 transparent PNG files.
- `assets/logos/`: unpacked, print-ready raster sources (not editable vectors).
- `assets/previews/`: JPG previews, **not** transparent / not print sources.
- `goods_logos_section.html`: embeddable HTML/CSS mockup for the existing Goods page.
- `USAGE_GUIDELINES_DRAFT_ja.txt`: proposed use terms; review and approve prior to public launch.
- `MANIFEST.json`: asset dimensions and SHA256 hashes.

## Website integration

Existing website Goods page: `https://funtasiaaudio.github.io/goods/?lang=ja` (GitHub repository `funtasiaaudio/funtasiaaudio.github.io`, path `goods/index.html`).

1. Review the usage policy; align it with how broadly you wish to allow community custom orders.
2. Publish the three ZIP files and thumbnails under a stable website path (for example `goods/downloads/` and `goods/previews/`) or upload ZIP assets to a GitHub release.
3. Insert the `goods_logos_section.html` markup, adjust URLs, and incorporate translations into existing 5-language site i18n (Japanese/English/German/French/Russian).
4. Preview in all five languages and on mobile. Verify every downloadable ZIP resolves before publishing.
5. Keep a backup / PR and avoid replacing existing wallpapers and cursor sections.

## Important quality notes

These are rasterized artwork previously developed in this chat. Some logos include generated typography and should be visually inspected against authoritative brand originals before treating them as final official identity assets. In particular, verify exact spelling of `Hʉeliang` and the line terminating at the right edge of `e`, not within `liang`. Fonts are not included.

PNG images are transparent RGB; preview JPG images are only for display. Individual print services may require different layouts and minimum print dimensions.
